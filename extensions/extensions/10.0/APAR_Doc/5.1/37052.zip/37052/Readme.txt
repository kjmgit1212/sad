
Steps to import the ddl\sql file(s) in the respective databases: 

 1. Extract the 37052.zip file to a temporary directory on your hard drive.
              
 2. Execute the following steps to apply the database schema change:
    
 	The ddl file(s) present in the database type specific directory, which contains a database script, 
        should be executed on your corresponding DB platforms (ie DB2,Oracle and SQL Server). 
        The script should be run by the database user configured for ITIM. 
        Copy the ddl\sql file(s) into some appropriate work directory of your choosing
        Run the scripts according to the instructions given below.
    
    SQL Server:
    -----------
        Use the Microsoft SQL Server "Query Analyzer" tool, or a supported SQL client to 
        execute the ddl script.
        In Initial Dialog "Connect to SQL Server", specify:
        User: enrole 
        Password: <enrole's configured password>
        Select menu "File" | "Open..."
        File name: <Full path name of 37052.sql shipped in mssql folder 
        	in 37052.zip>
        Select valid database from connection properties.
        Select "Execute".
        Select "File" | "Exit".
    
    Oracle:
    -------
        Run the Oracle sqlplus program. Specify your database user password for the
        enrole user in place of "PASSWORD", your Oracle ITIM instance name in place of
        "ITIMDB".
        sqlplus enrole/PASSWORD@ITIMDB
        > @<Full path name of 37052.ddl shipped in oracle folder in 37052.zip>
        > quit
    
    DB2:
    ----
        Type db2cmd to get the db2 prompt and on the prompt type the following:
             db2 connect to <dbname> user enrole using <enrole's password>
             db2 -tvf <Full path name of 37052.ddl shipped in db2 folder in 37052.zip>
 