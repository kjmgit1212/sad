#!/bin/sh

#/******************************************************************************
# *
# * Licensed Materials - Property of IBM
# *
# * Source File Name = UpdateTasksViewable.sh
# *
# * (C) COPYRIGHT IBM Corp. 2003, 2009 All Rights Reserved
# *
# * US Government Users Restricted Rights - Use, duplication or
# * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# *
# *****************************************************************************/

WAS_HOME=/opt/IBM/WebSphere/AppServer
ITIM_HOME=/opt/IBM/itim
JAVA_HOME=$WAS_HOME/java

CP=$CP:UpdateTasksViewable.jar
CP=$CP:$ITIM_HOME/lib/jlog.jar
CP=$CP:$ITIM_HOME/lib/itim_common.jar
CP=$CP:$ITIM_HOME/data
CP=$CP:$ITIM_HOME/lib/enroleagent.jar
CP=$CP:$JAVA_HOME/jre/lib/ext/ibmjceprovider.jar

# You can optionally edit classpath setting below as per your database provider(DB2/Oracle/SQLSever)
CP=$CP:$ITIM_HOME/lib/db2jcc.jar
CP=$CP:$ITIM_HOME/lib/db2jcc_license_cu.jar
CP=$CP:$ITIM_HOME/lib/ojdbc.jar
CP=$CP:$ITIM_HOME/lib/ojdbc14.jar
CP=$CP:$ITIM_HOME/lib/sqljdbc.jar

$JAVA_HOME/bin/java -cp $CP utility.UpdateTasksViewable "$@"

