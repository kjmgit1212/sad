
Some of the executables in ITIM add WebSphere 6.x jars to the classpath. If customer is running WebSphere 7.x, these jars are not available and should be replaced with the corresponding jar file names from WebSphere 7.x. The table below gives the list of the jar files names referenced from WebSphere 6.x and the corresponding name from WebSphere 7.x environment.

             WebSphere 6.x classpath entry                                      |                 WebSphere 7.x classpath entry
---------------------------------------------------------------------------------------------------------------------------------------------------
1.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.runtime_6.1.0.jar                   |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.runtime.jar
2.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.emf_2.1.0.jar                       |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.emf.jar
3.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.wccm_6.1.0.jar                      |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.wccm.jar
4.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.ejbportable_6.1.0.jar               |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.ejbportable.jar
5.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.security.crypto_6.1.0.jar           |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.security.crypto.jar
6.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.runtime_6.1.0.jar                   |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.runtime.jar
7.    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.emf_2.1.0.jar                       |    <WAS_INSTALL_ROOT>/plugins/com.ibm.ws.emf.jar
8.    <WAS_INSTALL_ROOT>/runtimes/com.ibm.ws.webservices.thinclient_6.1.0.jar   |    <WAS_INSTALL_ROOT>/runtimes/com.ibm.ws.webservices.thinclient_7.0.0.jar
9.    <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.security.crypto_6.1.0.jar        |    <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.security.crypto.jar
10.   <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.runtime_6.1.0.jar                |    <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.runtime.jar
11.   <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.emf_2.1.0.jar                    |    <WAS_DM_INSTALL_ROOT>/plugins/com.ibm.ws.emf.jar

Following are the executables in ITIM that reference one or more of the above class path entries. If you are running WebSphere 7.x, you will need to replace the WebSphere 6.x jar file name reference with the corresponding WebSphere 7.x file names.

On Windows systems:
1. <ITIM_HOME>\extensions\5.1\examples\apps\bin\win\setEnv.bat
2. <ITIM_HOME>\bin\win\changeCipher.cmd
3. <ITIM_HOME>\extensions\5.1\examples\dataservices\bin\win\RoleLoader.cmd

On Unix systems:
1. <ITIM_HOME>/extensions/5.1/examples/apps/bin/unix/setEnv.sh
2. <ITIM_HOME>/bin/unix/changeCipher.sh
3. <ITIM_HOME>/extensions/5.1/examples/dataservices/bin/unix/RoleLoader.sh
4. <ITIM_HOME>/extensions/5.1/examples/policyanalysis/runExample.sh

This zip file contains a copy of the above files that have been updated with WebSphere 7.x entries (commented out by default). You can use these files as a reference.
In addition to the above files the following lax files too contain the reference to WebSphere 6.x jar files. You can replace the WebSphere 6.x specific jar file names with the corresponding WebSphere 7.0 file names in following files.
1. <ITIM_HOME>/bin/DBConfig.lax 
2. <ITIM_HOME>/bin/DBUpgrade.lax 
3. <ITIM_HOME>/bin/ldapConfig.lax 
4. <ITIM_HOME>/bin/ldapUpgrade.lax 
5. <ITIM_HOME>/bin/runConfig.lax 

The path of ssl.client.props file in <ITIM_HOME>/extensions/5.1/examples/app/src/examples/api/Utils.java is incorrect. This has been updated and the updated file is provided in this zip. Perform the following steps to use the updated file.

1. Take a backup of <ITIM_HOME>/extensions/5.1/examples/app/src/examples/api/Utils.java.
2. Copy the Utils.java file present in this zip file to <ITIM_HOME>/extensions/5.1/examples/app/src/examples/api folder.
3. Please note that you will need to redo any customizations/changes done to this file.
4. If you have a clustered environment then please perform the above steps on each node of the cluster.

