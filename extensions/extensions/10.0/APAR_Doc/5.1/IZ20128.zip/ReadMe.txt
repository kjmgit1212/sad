APAR:    IZ20128
Symptom: Example ExternalLogonServlet.java not working properly.

An alternative example, examples.singlesignon.SampleSSOAdapter.java, has been provided.

The sample SampleSSOAdapter.java implements the interface com.ibm.itim.ui.sso.SSOAdapter.
Please refer to the following html files for the documentation of their respective java classes 
used in the example provided:

-SSOAdapter.html
-ITIMUIException.html
-ITIMUISSOUserIdNotFoundException.html

Please perform the below steps to work with the new example provided:

1. Copy 'SampleSSOAdapter.java' into '$ITIM_HOME/extensions/examples/singlesignon/src/examples/singlesignon' directory.
2. Copy 'ui_api.jar' from 'WAS_HOME/profiles/[profile]/installedApps/[cell]/ITIM.ear/'  into the directory ''$ITIM_HOME/extensions/lib�.
3. Run '$ITIM_HOME/extensions/examples/build.bat' to compile the example.
4. Stop the WebSphere Application Server.
5. Copy 'ITIM_HOME/extensions/lib/examples.jar' to the installed application. i.e into 'WAS_HOME/profiles/[profile]/installedApps/[cell]/ITIM.ear/'
6. Update/Add the following properties in ui.properties file in the $ITIM_HOME/data directory -
         enrole.ui.ssoEnabled=true
         ui.ssoAdapter=examples.singlesignon.SampleSSOAdapter
         enrole.ui.ssoEncoding=UTF-8
7. Start the WebSphere Application Server.
8. Following URLs should open the home page of 'itim manager' in browser-
         http://servername/itim/console/main?userID=itim manager, 
         http://servername/itim/self/jsp/logon/logon.do?userID=itim manager
