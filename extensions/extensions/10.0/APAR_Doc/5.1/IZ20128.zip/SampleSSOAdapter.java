/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2000, 2008 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/
package examples.singlesignon;

import javax.servlet.http.HttpServletRequest;

import com.ibm.itim.ui.exception.ITIMUIException;
import com.ibm.itim.ui.exception.ITIMUISSOUserIdNotFoundException;
import com.ibm.itim.ui.sso.SSOAdapter;

/**
 * Retrieves UserID and authentication state
 * The user id is expected in the "userID" request
 *
 */
public class SampleSSOAdapter implements SSOAdapter {

    /**
     * Given the request object return if the request has been authenticated
     * via an SSO provider
     *
     * @param request the servlet request
     * @return <code>true</code> if the request has been authenticated <code>false</code> otherwise
     * @throws ITIMUIException if an error occurs while checking the authentication state
     */
    public boolean isAuthenticated(HttpServletRequest request)
            throws ITIMUIException {
        String userId = (String) request.getParameter("userID");

        if (userId != null) {
            return true;
        } else {
            throw new ITIMUISSOUserIdNotFoundException("User ID missing");
        }
    }

    /**
     * returns the ITIM User ID that identifies the authenticated user. The SSO adapter should
     * use information stored in the HTTP request to identify the ITIM user. If the user id used
     * to the authenticate to the SSO provider does not match the ITIM user id, the adapter is
     * responsible for mapping/returning the itim user id.
     *
     * @param request the servlet request
     * @return the itim user id for the authenticated user.  This method should not return <code>null</code> or empty
     *  	string, but instead throw an exception if the user id is not found or valid
     * @throws ITIMUISSOUserIdNotFoundException if the sso adapter is unable to determine the itim user id
     * @throws ITIMUIException if an error occurs while determining the user id
     */
    public String getUserId(HttpServletRequest request)
            throws ITIMUISSOUserIdNotFoundException, ITIMUIException {

        String userId = (String) request.getParameter("userID");
        if ((userId == null) ||(userId.trim().equals(""))){
            throw new ITIMUISSOUserIdNotFoundException("User ID missing");
        }

        return userId;
    }
}