APAR:    IV07674
Symptom: Expose recertification policy APIs
Note:    As a part of this fix, the following new files have been added to provide few examples on the new API usage:
         1. $ITIM_HOME/extensions/5.1/examples/apps/bin/unix/changeRecertificationPolicy.sh
         2. $ITIM_HOME/extensions/5.1/examples/apps/bin/unix/createRecertificationPolicy.sh
         3. $ITIM_HOME/extensions/5.1/examples/apps/bin/unix/deleteRecertificationPolicy.sh
         4. $ITIM_HOME/extensions/5.1/examples/apps/bin/unix/executeRecertificationPolicy.sh
         5. $ITIM_HOME/extensions/5.1/examples/apps/bin/win/changeRecertificationPolicy.bat
         6. $ITIM_HOME/extensions/5.1/examples/apps/bin/win/createRecertificationPolicy.bat
         7. $ITIM_HOME/extensions/5.1/examples/apps/bin/win/deleteRecertificationPolicy.bat
         8. $ITIM_HOME/extensions/5.1/examples/apps/bin/win/executeRecertificationPolicy.bat
         9. $ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/ChangeRecertificationPolicy.java
         10.$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/CreateRecertificationPolicy.java
         11.$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/DeleteRecertificationPolicy.java
         12.$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/ExecuteRecertificationPolicy.java

         and following file has been modified with instructions on how to execute the examples:
         $ITIM_HOME/extensions/5.1/examples/apps/Readme.html

         Please perform following steps on each node of the cluster to work with the new example provided:
         1. The Fixpack installer might already have added following files in the '$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/' directory.
         a. ChangeRecertificationPolicy.java
         b. CreateRecertificationPolicy.java
         c. DeleteRecertificationPolicy.java
         d. ExecuteRecertificationPolicy.java
         Verify that these files exist in '$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/' directory. If not, then copy the files from 'apps/src/examples/api' directory present in this zip to '$ITIM_HOME/extensions/5.1/examples/apps/src/examples/api/' directory.

         2. Copy following files from 'apps/bin/unix/' directory present in this zip to '$ITIM_HOME/extensions/5.1/examples/apps/bin/unix/' directory.
         a. changeRecertificationPolicy.sh
         b. createRecertificationPolicy.sh
         c. deleteRecertificationPolicy.sh
         d. executeRecertificationPolicy.sh

         3. Copy following files from 'apps/bin/win/' directory present in this zip to '$ITIM_HOME/extensions/5.1/examples/apps/bin/win/' directory.
         a. changeRecertificationPolicy.bat
         b. createRecertificationPolicy.bat
         c. deleteRecertificationPolicy.bat
         d. executeRecertificationPolicy.bat

         Please refer to the $ITIM_HOME/extensions/5.1/examples/apps/Readme.html' file for instructions on building and running the examples.
