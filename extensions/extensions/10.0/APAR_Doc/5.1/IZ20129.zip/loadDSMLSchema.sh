#!/bin/sh
#/******************************************************************************
# *
# * Licensed Materials - Property of IBM
# *
# * Source File Name = loadDSMLSchema.sh
# *
# * (C) COPYRIGHT IBM Corp. 1999, 2007 All Rights Reserved
# *
# * US Government Users Restricted Rights - Use, duplication or
# * disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
# *
# *****************************************************************************/
# Usage: sh loadDSMLSchema.sh file [url] [user] [password] [protocol] 
# Set user-defined variables.

ITIM_HOME=%ENROLE_HOME%
JAVA_HOME=%JAVA_HOME%


CLASSPATH=.
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/jsafe.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/enroleagent.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/log4j.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/data
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/itim_common.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/itim_server_api.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/itim_api.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/itim_server.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/jlog.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/jffdc.jar
CLASSPATH=$CLASSPATH:$ITIM_HOME/lib/aspectjrt.jar


$JAVA_HOME/bin/java -classpath $CLASSPATH com.ibm.dsml.LoadDSMLSchema $1 $2 $3 $4 $5
