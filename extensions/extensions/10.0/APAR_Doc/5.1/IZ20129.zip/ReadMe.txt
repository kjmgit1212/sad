APAR:    IZ20129
Symptom: After enabling the SSL between ITIM and the directory server, custom services 
         in ITIM can not be configured and the runConfig operation fails.
Note:    As a part of this fix, the following files have been modified:
         $ITIM_HOME/bin/win/loadDSMLSchema.cmd  for Windows.
         $ITIM_HOME/bin/unix/loadDSMLSchema.sh  for Unix

If SSL is enabled between ITIM and the directory server, above files need to be copied into their respective locations.
Before executing the utilities, please make sure to set the following path variables:
ITIM_HOME and 
JAVA_HOME

You may also want to refer to the below URL for configuration procedures required in order to run the above utility successfully.

http://publib.boulder.ibm.com/infocenter/tivihelp/v2r1/index.jsp?topic=/com.ibm.itim.doc/ims500_install158.htm