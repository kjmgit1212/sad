This utility should be used to update the report template for the report "Individual Accounts By Role" in the ITIMDB for ITIM 5.1.

Instructions for updating OutofBox "Individual Accounts By Role" PDF/CSV Reports.

1. Take a backup copy of REPORT table of ITIM database.

2. Edit the script file UpdateCannedReport.bat (for windows) or UpdateCannedReport.sh (for non-windows) and set the following variables.
   - ITIM_HOME
   - JAVA_HOME
   - DRIVER_PATH
   
3. Run UpdateCannedReport.bat (for windows) or UpdateCannedReport.sh (for non-windows) using command prompt. Any errors or debug messages will be written to the standard output.


Instructions for Crystal Reports.

1. If IndividualAccountsByRole.rpt report has been configured as OutOfBox report then execute the following steps:
   a. Edit the script file 'CrystalConfigWAS.bat' present under '<ITIM-HOME>/bin/win' (for windows) or 'CrystalConfigWAS.sh' present under      '<ITIM-HOME>/bin/unix' (for non-windows) and set the following variables.
      - ITIM_HOME
      - WAS_HOME
      - NODE_NAME
      Make sure to add the JDBC drivers into the class path (e.g. db2java.zip and db2jcc.jar, in case of db2).
   
   b. Run CrystalConfigWAS.bat (for windows) using command prompt.

2. If IndividualAccountsByRole.rpt report has been configured as Custom report then you will need to reimport it once again from 
   <ITIM_HOME>/config/reports/crystal directory.

