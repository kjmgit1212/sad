#*****************************************************************************
# This Utility should be used to Update the OutOfBox report template for the report
# "Individual Accounts by Role"
#
#Set ITIM_HOME to the complete path of your ITIM installation directory.
#Set JAVA_HOME to point to java folder of WebSphere installation directory..
#Set DRIVER_PATH to point to the jdbc driver file.
#For example if database is DB2 and if db2 is installed in /opt/IBM/db2/V8.1/java then
#set DRIVER_PATH as /opt/IBM/db2/V8.1/java/db2java.zip
#similarly if database is Oracle please add ojdbc14.jar to classpath incase
#it is not already present in ITIM_HOME/lib directory. Usually this driver 
#is present in ORACLE_HOME/ora81/jdbc/lib or in ITIM-HOME/lib directory
#
#******************************************************************************

ITIM_HOME=/opt/IBM/itim
JAVA_HOME=/opt/WebSphere/AppServer/java
DRIVER_PATH=/opt/IBM/db2/V8.1/java/db2java.zip

CP=.
CP=$CP:$DRIVER_PATH
CP=$CP:$ITIM_HOME/lib/itim_server.jar
CP=$CP:$ITIM_HOME/lib/itim_api.jar
CP=$CP:$ITIM_HOME/lib/jlog.jar
CP=$CP:$ITIM_HOME/lib/aspectjrt.jar
CP=$CP:$ITIM_HOME/data

CP=$CP:updateCannedReport.jar

$JAVA_HOME/bin/java -DITIM_HOME=$ITIM_HOME -classpath $CP UpdateCannedReport $1

