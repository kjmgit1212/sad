    APAR:    IV08754  	RTC 46983	
    Symptom: Invalid syntax in generatePassword.cmd file results in failure
    Note:    Syntax correction is done in $ITIM_HOME/extensions/5.1/examples/passwordrules/generatePassword.cmd file.
             Please perform following steps on each node of the cluster to work with the this example provided:

			A. Take a backup of your existing $ITIM_HOME/extensions/5.1/examples/passwordrules/generatePassword.cmd file.
	        B. Replace the generatePassword.cmd file provided in IV08754.zip.
			
			Please refer to the $ITIM_HOME/extensions/5.1/examples/passwordrules/Readme.html' file for instructions on running the examples.