package com.wsclient;

import com.ibm.itim.ws.model.WSAccessBaseInfo;
import com.ibm.itim.ws.model.WSAccessEntitlement;
import com.ibm.itim.ws.model.WSPerson;
import com.ibm.itim.ws.model.WSSession;
import com.ibm.itim.ws.model.WSUserAccess;
import com.ibm.itim.ws.services.WSAccessService;
import com.ibm.itim.ws.services.WSPersonService;
import com.ibm.itim.ws.services.WSSessionService;

public class SampleClient {

	public static void main(String[] args) {
		WSSession session = null;
		int roleAccessIndex = -1, serviceGroupAccessIndex = -1;
		try {
			// Get a WSOPALClient object by passing the hostname/ip, where the
			// ISVG application is hosted, and the port information.
			SampleClientUtil util = new SampleClientUtil("10.77.88.13", "9080");
			// Get the WSSessionService
			WSSessionService sessionService = util.getWSSessionService();
			// Use the WSSessionService to login to ISVG
			session = sessionService.login("itim manager", "secret");

			System.out.println("Successfully logged into ISVG.");

			// Get the WSPerson object
			WSPersonService personService = util.getWSPersonService();
			WSPerson person = personService.getPrincipalPerson(session);
			String personDN = person.getItimDN();

			// Get the all the granted accesses using WSAccessService to for
			// available accessses, create
			// access for the person, get granted accesses to the person, and
			// remove granted accesses
			WSAccessService accessService = util.getWSAccessService();
			// Get all the granted accesses for the person
			util.printEntitiledAccessesForPerson(session, accessService,
					person);
			// Get all the available accesses for the person. The result
			// includes the granted and the availabled accesses
			WSAccessEntitlement[] availableAccessEntitlement = accessService
					.getAvailableAccessEntitlements(session, personDN);
			if (availableAccessEntitlement == null
					|| availableAccessEntitlement.length < 1) {
				System.out
						.println("There are no available access entitlements for person '"
								+ person.getName() + "'");
			} else {
				// Iterate through the returned WSAccessEntitlements and fetch
				// information about each of the accesses
				for (int i = 0; i < availableAccessEntitlement.length; i++) {
					// Getting the index of a role based access
					if (availableAccessEntitlement[i].isRoleAccess()
							&& (availableAccessEntitlement[i]
									.getAccessBaseInfo()[0].isGrantedAccess() == false)) {
						roleAccessIndex = i;
					}

					// Getting the index of a service group based access
					if (availableAccessEntitlement[i]
							.isAccountCreationRequired()
							&& (availableAccessEntitlement[i]
									.getAccessBaseInfo()[0].isGrantedAccess() == false)) {
						serviceGroupAccessIndex = i;
					}
					System.out
							.println("-----------------------------------------------------");
					System.out.println("Access Name                  : "
							+ availableAccessEntitlement[i].getName());

					System.out.println("Access Type                  : "
							+ availableAccessEntitlement[i].getAccessType());
					System.out
							.println("Is Account creation required : "
									+ (availableAccessEntitlement[i]
											.isAccountCreationRequired() ? "Yes"
											: "No"));
					System.out
							.println("Is a Role access             : "
									+ (availableAccessEntitlement[i]
											.isRoleAccess() ? "Yes" : "No"));

				}
			}

			// Requesting a Role based access for the person. For a role based
			// access, account creation is not required
			if (roleAccessIndex > -1) {
				accessService.createAccessForPerson(session,
						availableAccessEntitlement[roleAccessIndex], null,
						personDN);
				System.out
						.println("Create access request submitted successfully.");
				System.out
						.println("Waiting for 10000 milliseconds for the request to complete.");
				// Waiting for 10000 milliseconds for the request to complete
				Thread.sleep(10000);

				// Get all the granted accesses for the person
				util.printEntitiledAccessesForPerson(session, accessService,
						person);

			}

			// Requesting a service group based access for the person. For a
			// service based access, account creation is required
			if (serviceGroupAccessIndex > -1) {
				// Using the person name as the naming attribute for the
				// account. Assuming that an account with this name doesn't
				// exist
				String personName = person.getName();
				WSAccessBaseInfo[] accessBaseInfo = availableAccessEntitlement[serviceGroupAccessIndex]
						.getAccessBaseInfo();
				accessBaseInfo[0].setUserid(personName);
				accessBaseInfo[0].setPassword("Passw0rd");
				availableAccessEntitlement[serviceGroupAccessIndex]
						.setAccessBaseInfo(accessBaseInfo);
				accessService.createAccessForPerson(session,
						availableAccessEntitlement[serviceGroupAccessIndex],
						null, personDN);
				System.out
						.println("Create access request submitted successfully.");

				System.out
						.println("Waiting for 10000 milliseconds for the request to complete.");
				// Waiting for 10000 milliseconds for the request to complete
				Thread.sleep(10000);

				// Get all the granted accesses for the person
				util.printEntitiledAccessesForPerson(session, accessService,
						person);

			}

			// Remove the granted access
			WSUserAccess[] userAccess = accessService.getAccesses(session,
					person.getItimDN());
			if (userAccess != null && userAccess.length > 0) {
				for (int i = 0; i < userAccess.length; i++) {
					System.out.println("Removing the access '"
							+ userAccess[i].getAccessName() + "'");
					accessService.removeAccess(session, personDN,
							userAccess[i], null);
					System.out
							.println("Remove access request submitted successfully.");

					System.out
							.println("Waiting for 10000 milliseconds for the request to complete.");
					// Waiting for 10000 milliseconds for the request to
					// complete
					Thread.sleep(10000);
					util.printEntitiledAccessesForPerson(session,
							accessService, person);
				}

			} else {
				System.out
						.println("There are no access granted which can be removed.");
			}

			// accessService.createAccessForPerson(session,
			// availableAccessEntitlement[1], null, person.getItimDN());
			System.out.println("End of the sample");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
