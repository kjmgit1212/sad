package com.wsclient;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.ibm.itim.ws.model.WSPerson;
import com.ibm.itim.ws.model.WSSession;
import com.ibm.itim.ws.model.WSUserAccess;
import com.ibm.itim.ws.services.WSAccessService;
import com.ibm.itim.ws.services.WSPersonService;
import com.ibm.itim.ws.services.WSSessionService;
import com.ibm.itim.ws.services.facade.ITIMWebServiceFactory;

public class SampleClientUtil {

	private ITIMWebServiceFactory factory;

	private String hostname = "";

	private String port = "";

	private String url = "";

	public SampleClientUtil(String hostname, String port) {
		this.hostname = hostname;
		this.port = port;

		url = "http://" + hostname + ":" + port;
	}

	public WSSessionService getWSSessionService() throws MalformedURLException,
			ServiceException {
		if (factory == null)
			factory = new ITIMWebServiceFactory(url);

		WSSessionService sessionService = factory.getWSSessionService();
		return sessionService;
	}

	public WSAccessService getWSAccessService() throws MalformedURLException,
			ServiceException {
		if (factory == null)
			factory = new ITIMWebServiceFactory(url);

		WSAccessService accessService = factory.getWSAccessService();
		return accessService;
	}

	public WSPersonService getWSPersonService() throws MalformedURLException,
			ServiceException {
		if (factory == null)
			factory = new ITIMWebServiceFactory(url);

		WSPersonService personService = factory.getWSPersonService();
		return personService;
	}

	public void printEntitiledAccessesForPerson(WSSession session,
			WSAccessService accessService, WSPerson person)
			throws RemoteException {
		WSUserAccess[] userAccess = accessService.getAccesses(session, person
				.getItimDN());
		if (userAccess == null || userAccess.length < 1) {
			System.out.println("The person '" + person.getName()
					+ "' has no access entitlements.");
		} else {
			System.out.println("The person '" + person.getName()
					+ "' has the following access entitlements:");
			for (int i = 0; i < userAccess.length; i++) {
				System.out
						.println("-----------------------------------------------------");
				System.out.println("Access Name  : "
						+ userAccess[i].getAccessName());
				System.out.println("Access Type  : "
						+ userAccess[i].getAccessType());
			}
		}
	}
}
