package com.wsclient;

import java.util.ArrayList;
import java.util.List;

import com.ibm.itim.ws.model.WSAccessEntitlement;
import com.ibm.itim.ws.model.WSNewUserAccess;
import com.ibm.itim.ws.model.WSPerson;
import com.ibm.itim.ws.model.WSSession;
import com.ibm.itim.ws.model.WSUserAccess;
import com.ibm.itim.ws.services.WSAccessService;
import com.ibm.itim.ws.services.WSPersonService;
import com.ibm.itim.ws.services.WSSessionService;

// Not required imports
//import com.ibm.itim.ws.model.WSAccessBaseInfo;
public class SampleClient {

	public static void main(String[] args) {
		WSSession session = null;
		int roleAccessIndex = -1, serviceGroupAccessIndex = -1;
		try {
			// Get a WSOPALClient object by passing the hostname/ip, where the
			// ISVG application is hosted, and the port information.
			SampleClientUtil util = new SampleClientUtil("10.77.214.25", "9080");
			// Get the WSSessionService
			WSSessionService sessionService = util.getWSSessionService();
			// Use the WSSessionService to login to ISVG
			session = sessionService.login("itim manager", "secret");

			System.out.println("Successfully logged into ISVG.");

			// Get the WSPerson object
			WSPersonService personService = util.getWSPersonService();
			WSPerson person = personService.getPrincipalPerson(session);
			String personDN = person.getItimDN();

			// Get the all the granted accesses using WSAccessService to for
			// available accessses, create
			// access for the person, get granted accesses to the person, and
			// remove granted accesses
			WSAccessService accessService = util.getWSAccessService();
			// Get all the granted accesses for the person
			util
					.printEntitiledAccessesForPerson(session, accessService,
							person);
			// Get all the available accesses for the person. The result
			// includes the granted and the availabled accesses

			// The api availableAccessEntitlement is not supported use
			// searchAvailableAccessEntitlements to get all the available accesses
			// WSAccessEntitlement[] availableAccessEntitlement = accessService.
			// .getAvailableAccessEntitlements(session, personDN);
			List<WSAccessEntitlement> availableAccessEntitlement = accessService
					.searchAvailableAccessEntitlements(session, null, personDN,
							null, null);
			if (availableAccessEntitlement == null
					|| availableAccessEntitlement.size() < 1) {
				System.out
						.println("There are no available access entitlements for person '"
								+ person.getName() + "'");
			} else {
				// Iterate through the returned WSAccessEntitlements and fetch
				// information about each of the accesses
				for (int i = 0; i < availableAccessEntitlement.size(); i++) {
					// Getting the index of a role based access
					// The property roleAccess is removed from
					// WSAccessEntitlement and WSAccessBaseInfo is no more
					// available
					// If the serviceDN is null then it identifies that it is a
					// role based access.
					// You can call get access to find out if a given access is
					// granted to the person or not
					// if (availableAccessEntitlement.get(i).isRoleAccess()
					// && (availableAccessEntitlement.get(i)
					// .getAccessBaseInfo()[0].isGrantedAccess() == false)) {
					// roleAccessIndex = i;
					// }
					List<WSUserAccess> userAccess = accessService.getAccesses(
							session, personDN, availableAccessEntitlement
									.get(i).getAccessId());
					if ((availableAccessEntitlement.get(i).getServiceDN() == null)
							&& (userAccess != null && userAccess.size() == 0)) {
						roleAccessIndex = i;
					}

					// Getting the index of a service group based access
					// The property accountCreationRequired is removed from
					// WSAccessEntitlement
					// If serviceDN is not null identifies that its a service
					// group based access
					// if (availableAccessEntitlement[i]
					// .isAccountCreationRequired()
					// && (availableAccessEntitlement[i]
					// .getAccessBaseInfo()[0].isGrantedAccess() == false)) {
					// serviceGroupAccessIndex = i;
					// }
					if ((availableAccessEntitlement.get(i).getServiceDN() != null)
							&& (userAccess != null && userAccess.size() == 0)) {
						serviceGroupAccessIndex = i;
					}
					System.out
							.println("-----------------------------------------------------");
					System.out.println("Access Name                  : "
							+ availableAccessEntitlement.get(i).getName());

					System.out
							.println("Access Type                  : "
									+ availableAccessEntitlement.get(i)
											.getAccessType());
					System.out.println("Is Account creation required : "
							+ ((availableAccessEntitlement.get(i)
									.getServiceDN() != null) ? "Yes" : "No"));
					System.out.println("Is a Role access             : "
							+ ((availableAccessEntitlement.get(i)
									.getServiceDN() == null) ? "Yes" : "No"));

				}
			}

			// Requesting a Role based access for the person. For a role based
			// access, account creation is not required
			if (roleAccessIndex > -1) {
				List<WSNewUserAccess> wsNewUserAccessLst = new ArrayList<WSNewUserAccess>();
				// Use the WSNewUserAccess to create access for a person
				// For creating an access for role based access specify only the
				// Owner DN
				WSNewUserAccess wnua = new WSNewUserAccess();
				wnua.setUserId(null);
				wnua.setPassword(null);
				wnua.setAccountDN(null);
				wnua.setOwnerDN(personDN);
				wsNewUserAccessLst.add(wnua);

				// createAccessForPerson is not supported use createAccess
				// accessService.createAccessForPerson(session,
				// availableAccessEntitlement.get(roleAccessIndex), null,
				// personDN);
				accessService.createAccess(session, availableAccessEntitlement
						.get(roleAccessIndex), wsNewUserAccessLst, null);
				System.out
						.println("Create access request submitted successfully.");
				System.out
						.println("Waiting for 10000 milliseconds for the request to complete.");
				// Waiting for 10000 milliseconds for the request to complete
				Thread.sleep(10000);

				// Get all the granted accesses for the person
				util.printEntitiledAccessesForPerson(session, accessService,
						person);

			}

			// Requesting a service group based access for the person. For a
			// service based access, account creation is required
			if (serviceGroupAccessIndex > -1) {
				// Using the person name as the naming attribute for the
				// account. Assuming that an account with this name doesn't
				// exist
				String personName = person.getName();
				// WSAccessBaseInfo is no longer supported use WSNewUserAccess
				// WSAccessBaseInfo[] accessBaseInfo =
				// availableAccessEntitlement[serviceGroupAccessIndex]
				// .getAccessBaseInfo();
				// accessBaseInfo[0].setUserid(personName);
				// accessBaseInfo[0].setPassword("Passw0rd");
				// availableAccessEntitlement[serviceGroupAccessIndex]
				// .setAccessBaseInfo(accessBaseInfo);

				List<WSNewUserAccess> wsNewUserAccessLst = new ArrayList<WSNewUserAccess>();

				// Use the WSNewUserAccess to create access for a person
				// For creating a new account specify UserId, Password, and
				// Person DN
				// For using an existing account specify AccountDN and Person DN
				WSNewUserAccess wnua = new WSNewUserAccess();
				wnua.setUserId(personName);
				wnua.setPassword("Passw0rd");
				wnua.setAccountDN(null);
				wnua.setOwnerDN(personDN);
				wsNewUserAccessLst.add(wnua);

				// createAccessForPerson is not supported use createAccess
				// accessService.createAccessForPerson(session,
				// availableAccessEntitlement[serviceGroupAccessIndex],
				// null, personDN);
				accessService
						.createAccess(session, availableAccessEntitlement
								.get(serviceGroupAccessIndex),
								wsNewUserAccessLst, null);
				System.out
						.println("Create access request submitted successfully.");

				System.out
						.println("Waiting for 10000 milliseconds for the request to complete.");
				// Waiting for 10000 milliseconds for the request to complete
				Thread.sleep(10000);

				// Get all the granted accesses for the person
				util.printEntitiledAccessesForPerson(session, accessService,
						person);

			}

			// Remove the granted access
			List<WSUserAccess> userAccess = accessService.getAccesses(session,
					personDN, null);
			if (userAccess != null && userAccess.size() > 0) {
				for (WSUserAccess access : userAccess) {
					System.out.println("Removing the access '"
							+ access.getAccessName() + "'");
					// Signature of removeAccess has changed
					// accessService.removeAccess(session, personDN,
					// userAccess[i], null);
					accessService.removeAccess(session, access, null);
					System.out
							.println("Remove access request submitted successfully.");

					System.out
							.println("Waiting for 10000 milliseconds for the request to complete.");
					// Waiting for 10000 milliseconds for the request to
					// complete
					Thread.sleep(10000);
					util.printEntitiledAccessesForPerson(session,
							accessService, person);
				}

			} else {
				System.out
						.println("There are no access granted which can be removed.");
			}

			// accessService.createAccessForPerson(session,
			// availableAccessEntitlement[1], null, person.getItimDN());
			System.out.println("End of the sample");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
