package com.wsclient;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import javax.xml.namespace.QName;

import com.ibm.itim.ws.model.WSPerson;
import com.ibm.itim.ws.model.WSSession;
import com.ibm.itim.ws.model.WSUserAccess;
import com.ibm.itim.ws.services.WSAccessService;
import com.ibm.itim.ws.services.WSAccessServiceService;
import com.ibm.itim.ws.services.WSApplicationException;
import com.ibm.itim.ws.services.WSLoginServiceException;
import com.ibm.itim.ws.services.WSPersonService;
import com.ibm.itim.ws.services.WSPersonServiceService;
import com.ibm.itim.ws.services.WSSessionService;
import com.ibm.itim.ws.services.WSSessionService_Service;

// The facage ITIMWebServiceFactory is not available.
//import com.ibm.itim.ws.services.facade.ITIMWebServiceFactory;

//Not required imports
//import javax.xml.rpc.ServiceException;

public class SampleClientUtil {

	static final String WS_SUFFIX = "/itim/services/";

	static final String WS_WSDL_LOCATION = "/WEB-INF/wsdl/";

	static final String namespaceURI = "http://services.ws.itim.ibm.com";

	private String hostname = "";

	private String port = "";

	private URL generateServiceURL(String serviceName,
			String serviceWSDLFileName) {

		String strURL = "http://" + hostname + ":" + port + WS_SUFFIX
				+ serviceName + WS_WSDL_LOCATION + serviceWSDLFileName;
		URL url = null;
		try {
			url = new URL(strURL);
		} catch (MalformedURLException e) {
			System.out.println("Failed to generate the wsdl resource URL");
			e.printStackTrace();
			System.exit(-1);
		}
		return url;
	}

	public SampleClientUtil(String hostname, String port) {
		this.hostname = hostname;
		this.port = port;
	}

	public WSSessionService getWSSessionService() {
		WSSessionService_Service service = null;
		URL url = null;
		String serviceName = "WSSessionService";

		if ((url = generateServiceURL(serviceName, "WSSessionService.wsdl")) != null) {
			service = new WSSessionService_Service(url, new QName(namespaceURI,
					serviceName));
		} else {
			return null;
		}

		WSSessionService proxy = service.getWSSessionServicePort();
		return proxy;
	}

	public WSAccessService getWSAccessService() {
		WSAccessServiceService service = null;
		URL url = null;
		String serviceName = "WSAccessServiceService";
		if ((url = generateServiceURL(serviceName, "WSAccessService.wsdl")) != null) {
			service = new WSAccessServiceService(url, new QName(namespaceURI,
					serviceName));
		} else {
			return null;
		}

		WSAccessService proxy = service.getWSAccessService();
		return proxy;
	}

	public WSPersonService getWSPersonService() {
		WSPersonServiceService service = null;
		URL url = null;
		String serviceName = "WSPersonServiceService";
		if ((url = generateServiceURL(serviceName, "WSPersonService.wsdl")) != null) {
			service = new WSPersonServiceService(url, new QName(namespaceURI,
					serviceName));
		} else {
			return null;
		}

		WSPersonService proxy = service.getWSPersonService();
		return proxy;

	}

	public void printEntitiledAccessesForPerson(WSSession session,
			WSAccessService accessService, WSPerson person)
			throws WSApplicationException, WSLoginServiceException {
		// The signature of getAccesses has changed
		// WSUserAccess[] userAccess = accessService.getAccesses(session, person
		// .getItimDN(), null);
		List<WSUserAccess> userAccess = accessService.getAccesses(session,
				person.getItimDN(), null);
		if (userAccess == null || userAccess.size() < 1) {
			System.out.println("The person '" + person.getName()
					+ "' has no access entitlements.");
		} else {
			System.out.println("The person '" + person.getName()
					+ "' has the following access entitlements:");
			for (WSUserAccess access : userAccess) {
				System.out
						.println("-----------------------------------------------------");
				System.out.println("Access Name  : " + access.getAccessName());
				System.out.println("Access Type  : " + access.getAccessType());
			}
		}
	}
}
