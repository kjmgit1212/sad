/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2009 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/

package com.ibm.itim.hookedreport;

/**
 * This class contains all the constants that are required for generating Reconciliation Hooked Report
 */
public class Constants {

	public static final String SS = "SUCCESS";

	public static final String SF = "FAILED";

	public static final String SW = "The last reconciliation for this service had warnings.";

	public static final String NO_LAST_RECON = "A valid last reconciliation was not found for this service.";

	public static final String SHOW_SERVICE = "showservice";

	public static final String SHOW_RECONS = "showrecons";

	public static final String SHOW_REPORT = "showreport";

	public static final String END_OF_LINE = "\n";

	public static final String QUOTE = "\"";

	public static final String COMMA = ",";
	
	public static final String  SERVICE_PAGE_TITLE="Select A Service";
	
	public static final String  RECON_PAGE_TITLE="All Reconciliations performed on service ";

	public static final String CSV_ID_FEED_CLASS = "ercsvfeed";

	public static final String AD_ID_FEED_CLASS = "eradjndifeed";

	public static final String INETPERSON_ID_FEED_CLASS = "erjndifeed";

	public static final String DSML_ID_FEED_CLASS = "erDSMLInfoService";

	public static final String IDI_DATAFEED_CLASS = "erDSML2Service";

	// constants for Operations specific to Recon
	public static final String PERSONS_ADDED_OPERATION = "AP";

	public static final String PERSONS_MODIFIED_OPERATION = "MP";

	public static final String FAILED_ADD_PERSON_OPERATION = "FAP";

	public static final String FAILED_MODIFY_PERSON_OPERATION = "FMP";

	public static final String UNCHANGED_PERSON_OPERATION = "UP";

	public static final String PENDING_ADD_PERSON_OPERATION = "PAP";

	public static final String PENDING_MODIFY_PERSON_OPERATION = "PMP";

	public static final String RECON_WORKFLOW_DEFINITION_ID_PERSON_ADD = "CREATEPERSON";

	public static final String RECON_WORKFLOW_DEFINITION_ID_PERSON_MODIFY = "MODIFYPERSON";

	// is specific for DSML Recon without workflow
	public static final long RECON_NO_WORKFLOW_PROCESSID = -1L;

	// for Account Recons
	public static final String ORPHAN_ACCOUNTS_OPERATION = "NO";

	public static final String MODIFIED_ACCOUNTS_OPERATION = "MA";

	public static final String REMOVED_LOCAL_ACCOUNTS_OPERATION = "RL";

	public static final String DEPROVISIONED_ACCOUNT_OPERATION = "DA";

	public static final String SUSPENDED_ACCOUNT_OPERATION = "SA";

	public static final String NEW_LOCAL_ACCOUNTS_OPERATION = "NL";

	public static final String POLICY_VIOLATION_OPEATION = "FP";

	public static final String QUERY_FOR_SERVICE_NAME_FROM_SERVICE_DN = "SELECT ERSERVICENAME FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "SERVICE WHERE DN LIKE ?";

	public static final String QEURY_FOR_SERVICES_WITHRECONS = "SELECT DN, ERSERVICENAME,SERVICETYPE FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "SERVICE WHERE DN IN( SELECT DISTINCT(SERVICEDN) FROM RECONCILIATION)";

	public static final String QEURY_FOR_ALL_RECONS_ON_A_SERVICE = "SELECT RECONID, STARTED, COMPLETED FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION WHERE SERVICEDN LIKE ?";

	public static final String QEURY_FOR_TARGETCLASS_FROM_SERVICE = "SELECT TARGETCLASS FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "SERVICE WHERE SERVICE.DN LIKE ?";

	public static final String QUERY_FOR_COMPLETEDDATE_AND_ACTIVITYID_FROM_RECON = "SELECT COMPLETED,ACTIVITY_ID FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION WHERE RECONID LIKE ?";

	public static final String QUERY_FOR_RECON_STATUS_FROM_PROCESS = "SELECT PROCESS.RESULT_SUMMARY FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "PROCESS WHERE PROCESS.ID =(SELECT ACTIVITY.PROCESS_ID FROM ACTIVITY  WHERE ACTIVITY.ID = ? )";

	public static final String QUERY_FOR_RECON_SUMMARY_OF_ACCOUNT = "SELECT PROCESSEDACCOUNTS, TIMUSERACCOUNTS, POLICYVIOLATIONS, LOCALACCOUNTS FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION WHERE RECONID = ?";

	public static final String QUERY_FOR_RECON_SUMMARY_OF_PERSON = "SELECT PROCESSEDACCOUNTS FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION WHERE RECONID = ?";

	public static final String QUERY_FOR_COUNT_OF_ENTRIES_FROM_RECON_INFO = "SELECT COUNT(ACCOUNTID) FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO WHERE RECONID = ? AND OPERATION = ?";

	public static final String QUERY_FOR_ENTRIES_FROM_RECON_INFO = "SELECT RECONCILIATION_INFO.ACCOUNTID FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO WHERE RECONID = ? AND OPERATION = ?";

	public static final String QUERY_FOR_CHECK_WORKFLOW = "SELECT COUNT(HANDLE) FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO WHERE RECONID = ? AND ( HANDLE<> -1 )";

	public static final String QUERY_FOR_PENDING_ADD_MODIFY_ENTRIES = "SELECT COUNT(ACCOUNTID) FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO, "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "ACTIVITY WHERE (ACTIVITY.PROCESS_ID = RECONCILIATION_INFO.HANDLE) AND (ACTIVITY.RESULT_SUMMARY='SS') AND (RECONID = ?) AND (OPERATION = ?) AND ( char(ACTIVITY.DEFINITION_ID) = ?)";

	// public static final String QUERY_FOR_PENDING_MODIFY_ENTRIES = "SELECT
	// COUNT(ACCOUNTID) FROM RECONCILIATION_INFO, ACTIVITY WHERE
	// (ACTIVITY.PROCESS_ID = RECONCILIATION_INFO.HANDLE) AND
	// (ACTIVITY.RESULT_SUMMARY='SS') AND (RECONID = ?) AND (OPERATION = ?) AND
	// ( ACTIVITY.DEFINITION_ID = ?)";

	public static final String QUERY_FOR_ENTRIES_FOR_PERSONS_WITH_WORKFLOW = "SELECT ACCOUNTID FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO, "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "ACTIVITY WHERE (ACTIVITY.PROCESS_ID = RECONCILIATION_INFO.HANDLE) AND (ACTIVITY.RESULT_SUMMARY='SS') AND (RECONID = ?) AND (OPERATION = ?) AND ( ACTIVITY.DEFINITION_ID like = ?)";

	public static final String QUERY_FOR_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW = "SELECT ACCOUNTID FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO WHERE RECONID = ? AND OPERATION LIKE ?";

	public static final String QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITH_WORKFLOW = "SELECT RECONCILIATION_INFO.ACCOUNTID, ACTIVITY.RESULT_DETAIL FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO, "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "ACTIVITY WHERE (ACTIVITY.PROCESS_ID = RECONCILIATION_INFO.HANDLE) AND (ACTIVITY.RESULT_SUMMARY='SS') AND (RECONID = ?) AND ((OPERATION = ?) AND ( ACTIVITY.DEFINITION_ID like = ?))OR((OPERATION = ?) AND ( ACTIVITY.DEFINITION_ID like = ?) )";

	public static final String QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW = "SELECT ACCOUNTID, REMARKS FROM "
			+ DBConnectionConstants.DATABASE_OWNER
			+ "."
			+ "RECONCILIATION_INFO WHERE (OPERATION = 'FAP') OR (OPERATION = 'FMP') AND RECONID = ?";
	
	public static final String UNION="UNION ALL";
	
	
	public static final String QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITH_WORKFLOW_2="SELECT RECONCILIATION_INFO.ACCOUNTID, RESULT_DETAIL FROM RECONCILIATION_INFO, PROCESS WHERE (PROCESS.ID = RECONCILIATION_INFO.HANDLE) AND (PROCESS.RESULT_SUMMARY<>'SS') AND (RECONCILIATION_INFO.RECONID = ?) AND PROCESS.ID NOT IN (SELECT ACTIVITY.PROCESS_ID FROM ACTIVITY WHERE ACTIVITY.DEFINITION_ID = 'CREATEPERSON' OR ACTIVITY.DEFINITION_ID = 'MODIFYPERSON' )";

	//public static final String QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITH_WORKFLOW_1="SELECT RECONCILIATION_INFO.ACCOUNTID, ACTIVITY.RESULT_DETAIL FROM RECONCILIATION_INFO, ACTIVITY WHERE (ACTIVITY.PROCESS_ID = RECONCILIATION_INFO.HANDLE) AND (ACTIVITY.RESULT_SUMMARY<>'SS') AND ");"

}
