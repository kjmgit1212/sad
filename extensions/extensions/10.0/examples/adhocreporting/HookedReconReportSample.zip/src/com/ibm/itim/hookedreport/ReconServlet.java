/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2009 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/

package com.ibm.itim.hookedreport;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * This class implements a sample Hooked Report For Reconciliation Data.
 * This basically Retrieves all the Reconciliations for the service selected by user from Reconiciliation_Info Table
 * And further generates a CSV report for the particular reconciliation specified b start & completion date
 *
 */
public class ReconServlet extends javax.servlet.http.HttpServlet implements
		javax.servlet.Servlet {
	/*
	 * (non-Java-doc)
	 *
	 * @see javax.servlet.http.HttpServlet#HttpServlet()
	 */

	private Connection con;

	private ResultSet rs;

	private PreparedStatement pstatement;

	private PrintWriter out;

	public ReconServlet() {
		super();
	}

	/*
	 * (non-Java-doc)
	 *
	 * @see javax.servlet.http.HttpServlet#doGet(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		out=response.getWriter();

		try {
			Class.forName(DBConnectionConstants.DATABASE_DRIVER);
			con = DriverManager.getConnection(
					DBConnectionConstants.DATABASE_URL,
					DBConnectionConstants.USERNAME,
					DBConnectionConstants.PASSWORD);


		} catch (Exception e) {
			System.out
					.println("Error occurred while Connecting to Database. Please Check the DBConnectionConstants properties");

			out.println("<html>");
			out.println("<body>");
			out.println("Error occurred while Connecting to Database. Please Check the DBConnectionConstants properties");
			out.println("</body>");
			out.println("</html>");
			out.close();
			safeClose(con);
			}

		try {
			HttpSession session = request.getSession(true);
			String step = request.getParameter("step");

			String context = request.getParameter("context");

			if (step == null) {
				step = Constants.SHOW_SERVICE;
			}
			if (context != null) {
				if (context.equalsIgnoreCase("BACK"))
					step = Constants.SHOW_SERVICE;
				else
					step = Constants.SHOW_REPORT;
			}
			// Displays the html page showing all the services on which Reconciliation is performed.

			if (step.equalsIgnoreCase(Constants.SHOW_SERVICE)) {

				pstatement = con
						.prepareStatement(Constants.QEURY_FOR_SERVICES_WITHRECONS);
				rs = pstatement.executeQuery();
				generateHtml(rs, Constants.SHOW_RECONS,
						Constants.SERVICE_PAGE_TITLE, "Service Name",
						"Service Type", "servicedn");
				safeClose(rs);
				safeClose(pstatement);
			} // Displays the Html page showing all the Recons on the service selected by user
			else if (step.equalsIgnoreCase(Constants.SHOW_RECONS)) {

				String selectedservicedn = request.getParameter("servicedn");
				session.setAttribute("selectedservicedn", selectedservicedn);

				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_SERVICE_NAME_FROM_SERVICE_DN);
				pstatement.setString(1, selectedservicedn);
				rs = pstatement.executeQuery();
				String selectedservicename = null;
				if (rs.next()) {
					selectedservicename = rs.getString(1);
				}
				safeClose(rs);
				safeClose(pstatement);
				if (selectedservicedn != null) {
					pstatement = con
							.prepareStatement(Constants.QEURY_FOR_ALL_RECONS_ON_A_SERVICE);
					pstatement.setString(1, selectedservicedn);

					rs = pstatement.executeQuery();
					generateHtml(rs, Constants.SHOW_REPORT,
							Constants.RECON_PAGE_TITLE + selectedservicename,
							"Start Date", "Completed Date", "recon");
					safeClose(rs);
					safeClose(pstatement);

				}

			} // displays the Report containing the data for Particular Recon
			else if (step.equalsIgnoreCase(Constants.SHOW_REPORT)) {

				String selectedreconid = request.getParameter("recon");
				StringBuffer returnString = new StringBuffer();
				String selectedservicedn = (String) session
						.getAttribute("selectedservicedn");

				// check for type of reconciliation
				pstatement = con
						.prepareStatement(Constants.QEURY_FOR_TARGETCLASS_FROM_SERVICE);
				pstatement.setString(1, selectedservicedn);
				rs = pstatement.executeQuery();
				if (rs.next()) {
					String targetClass = rs.getString(1);

					if (targetClass.equals(Constants.CSV_ID_FEED_CLASS)
							|| targetClass.equals(Constants.AD_ID_FEED_CLASS)
							|| targetClass
									.equals(Constants.INETPERSON_ID_FEED_CLASS)
							|| targetClass.equals(Constants.DSML_ID_FEED_CLASS)
							|| targetClass.equals(Constants.IDI_DATAFEED_CLASS)) {

						returnString.append(appendRecondata(selectedreconid));
						returnString
								.append(appendPersonReconciliationdata(selectedreconid));
						safeClose(rs);
						safeClose(pstatement);

					} else {
						returnString.append(appendRecondata(selectedreconid));

						returnString
								.append(appendAccountReconciliationSummarydata(selectedreconid));

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.NEW_LOCAL_ACCOUNTS_OPERATION);
						returnString.append(addTableToReport(rs,
								"New Local Accounts"));
						safeClose(rs);
						safeClose(pstatement);

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.ORPHAN_ACCOUNTS_OPERATION);
						returnString.append(addTableToReport(rs,
								"Orphan Accounts"));
						safeClose(rs);
						safeClose(pstatement);

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.MODIFIED_ACCOUNTS_OPERATION);
						returnString.append(addTableToReport(rs,
								"Modified Accounts"));
						safeClose(rs);
						safeClose(pstatement);

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.REMOVED_LOCAL_ACCOUNTS_OPERATION);
						returnString.append(addTableToReport(rs,
								"Removed Local Accounts"));
						safeClose(rs);
						safeClose(pstatement);

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.DEPROVISIONED_ACCOUNT_OPERATION);
						returnString.append(addTableToReport(rs,
								"Deprovisioned Accounts"));
						safeClose(rs);
						safeClose(pstatement);

						rs = getEntriesFromReconInfoTable(selectedreconid,
								Constants.SUSPENDED_ACCOUNT_OPERATION);
						returnString.append(addTableToReport(rs,
								"Suspended Accounts"));
						safeClose(rs);
						safeClose(pstatement);

					}
				}

				response.setHeader("Content-type", "text/plain");
				response.setHeader("Content-Disposition",
						"attachment; filename=ReconReport.csv");

				String result = returnString.toString();
				byte[] content = result.getBytes("UTF-8");
				response.setContentLength(content.length);
				out.write(result);
				out.flush();

			}
		} catch (Exception e) {
			System.out
					.println("Error occurred while processing the request. Please contact your system administrator");
			e.printStackTrace();
			out.println("<html>");
			out.println("<body>");
			out.println("Error occurred while processing the request. Please contact your system administrator");
			out.println("</body>");
			out.println("</html>");
			out.close();

		}
		finally{
			safeClose(con);
			safeClose(pstatement);
			safeClose(rs);
		}


	}

	private void generateHtml(ResultSet rs, String stepValue, String htmlTitle,
			String ColHeader1, String colHeader2, String radioButtonName) {

		String astepValue = stepValue;
		out.println("<html>");
		out.println("<head>");
		out.println("<style type=text/css>");
		out.println("th { background: #fff; text-align: left; }");

		// To modify the size of the table make changes in the values of the variables - height and width

		out.println("div { height: 450px;   overflow: auto;   width: 700px; }");
		out.println("html>body");
		out.println("div { overflow: hidden;   width: 700px; }");

		//value of the width here same as the above
		out.println("div table { width: 700px; }");
		out.println("html>body div table   {   width: 700px; }");
		out.println("thead tr {   position: relative; }");
		out.println("html>body thead tr {   display: block; } ");
		out
				.println("html>body tbody { display: block; height: 450px; overflow: auto; width: 100% }");
		out.println("</style> <!--[if IE]>");
		out.println("<style type= text/css>");
		out.println("div { overflow: hidden; overflow-y: auto; }");
		out.println("</style> <![endif]-->");
		out.println("<b>");
		out.println("<font size =4 >");
		out.println("Reconciliation Report");
		out.println("</Font>");
		out.println("</b>");
		out.println("</head>");

		out.println("<body>");
		out.println("<FORM ACTION=../report/reconreport method=get>");
		out.println("<input type=hidden id=step name=step value=" + stepValue
				+ " />");

		out.println("<br>");
		out.println("<b>");
		out.println("" + htmlTitle);
		out.println("</b>");
		out.println("<br>");
		out.println("<br>");

		out.println("<div> ");
		out.println("<table border=1 align=center>");
		out.println("<thead>");
		out.println("<tr>");
		out.println("<th>&nbsp;</th>");
		out.println("<th>" + ColHeader1 + "</th>");
		out.println("<th>" + colHeader2 + "</th>");
		out.println("</tr>");
		out.println("</thead>");
		out.println("<tbody>");
		boolean isfirst = false;

		try {
			while (rs.next()) {
				String id = rs.getString(1);
				String col1 = rs.getString(2);
				String col2 = rs.getString(3);

				out.println("<TR>");
				out.println("<TD>");
				if (!isfirst) {
					out.println("<INPUT TYPE= radio NAME=" + radioButtonName
							+ " value=" + id + " CHECKED >");
					isfirst = true;
				} else {
					out.println("<INPUT TYPE= radio NAME=" + radioButtonName + " value=" + id
							+ ">");
				}
				out.println("</TD>");
				out.println("<TD align=left>" + col1 + "</TD>");
				out.println("<TD align=left>" + col2 + "</TD>");
				out.println("</TR>");



			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception while processing the ResultSet values");
			e.printStackTrace();
		}
		finally{
			safeClose(rs);
			safeClose(pstatement);
		}
		out.println("</tbody>");
		out.println("</table>");
		out.println("</div> ");
		out.println("<br>");
		out.println("<br>");
		out.println("<br>");
		out.println("<input type=submit value=Next>");
		if (astepValue.equalsIgnoreCase(Constants.SHOW_REPORT)) {
			out.println("<input type=submit name=context value=Back>");
		}
		out.println("<br>");
		out.println("</FORM>");
		out.println("</body>");
		out.println("</html>");
		// TODO Auto-generated method stub

	}

	//function to add Date and Status to Report
	private StringBuffer appendRecondata(String selectedreconid)
			throws SQLException {

		StringBuffer returnStringBuffer = new StringBuffer();
		pstatement = con
				.prepareStatement(Constants.QUERY_FOR_COMPLETEDDATE_AND_ACTIVITYID_FROM_RECON);
		pstatement.setString(1, selectedreconid);
		rs = pstatement.executeQuery();
		String completed_date = null;
		long activity_id = 0;
		if (rs.next()) {
			completed_date = rs.getString(1);
			activity_id = rs.getLong(2);
		}
		safeClose(rs);
		safeClose(pstatement);
		pstatement = con
				.prepareStatement(Constants.QUERY_FOR_RECON_STATUS_FROM_PROCESS);
		pstatement.setLong(1, activity_id);

		rs = pstatement.executeQuery();
		String reconStatus = null;
		if (rs.next()) {

			reconStatus = rs.getString(1);
			if (reconStatus.equalsIgnoreCase("SS"))
				reconStatus = Constants.SS;
			else if (reconStatus.equalsIgnoreCase("SW"))
				reconStatus = Constants.SW;
			else if (reconStatus.equalsIgnoreCase("SF"))
				reconStatus = Constants.SF;
			else
				reconStatus = Constants.NO_LAST_RECON;

		}
		safeClose(rs);
		safeClose(pstatement);
		// check status and assign string values

		returnStringBuffer.append(Constants.QUOTE + "Reconciliation Status"
				+ Constants.QUOTE + Constants.COMMA + reconStatus);
		returnStringBuffer.append(Constants.END_OF_LINE);
		returnStringBuffer.append(Constants.END_OF_LINE);

		returnStringBuffer.append(Constants.QUOTE + "Completed date & Time"
				+ Constants.QUOTE + Constants.COMMA + completed_date);
		returnStringBuffer.append(Constants.END_OF_LINE);
		returnStringBuffer.append(Constants.END_OF_LINE);

		return returnStringBuffer;

	}

	//Function to add data specific to Person Recons
	private StringBuffer appendPersonReconciliationdata(String reconId)
			throws SQLException {

		int personsFailed = 0;
		int personsAdded = 0;
		int personsModified = 0;
		int entriesProcessed = 0;
		boolean isWorkflow;
		boolean addFailedPerson = false;
		StringBuffer returnStringBuffer = new StringBuffer();

		pstatement = con
				.prepareStatement(Constants.QUERY_FOR_RECON_SUMMARY_OF_PERSON);
		pstatement.setString(1, reconId);
		rs = pstatement.executeQuery();
		if (rs.next()) {
			entriesProcessed = rs.getInt(1);

		}
		safeClose(rs);
		safeClose(pstatement);
		isWorkflow = checkforworkflow(reconId);

		personsFailed = getCountOfEntriesFromReconInfoTable(reconId,
				Constants.FAILED_ADD_PERSON_OPERATION);

		if (personsFailed > 0)
			addFailedPerson = true;

		if (isWorkflow) {

			// count added person
			pstatement = con
					.prepareStatement(Constants.QUERY_FOR_PENDING_ADD_MODIFY_ENTRIES);
			pstatement.setString(1, reconId);
			pstatement.setString(2, Constants.PENDING_ADD_PERSON_OPERATION);
			pstatement.setString(3,
					Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_ADD);
			rs = pstatement.executeQuery();
			if (rs.next()) {
				personsAdded = rs.getInt(1);

			}
			safeClose(rs);
			safeClose(pstatement);
			// count person modified

			pstatement = con
					.prepareStatement(Constants.QUERY_FOR_PENDING_ADD_MODIFY_ENTRIES);

			pstatement.setString(1, reconId);
			pstatement.setString(2, Constants.PENDING_MODIFY_PERSON_OPERATION);
			pstatement.setString(3,
					Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_MODIFY);
			rs = pstatement.executeQuery();
			if (rs.next()) {
				personsModified = rs.getInt(1);

			}
			safeClose(rs);
			safeClose(pstatement);
			//count persons failed
			//consider the pending add/modify entries as failed entries
			personsFailed = personsFailed + personsAdded + personsModified;
		}

		else {

			personsAdded = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.PERSONS_ADDED_OPERATION);

			personsModified = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.PERSONS_MODIFIED_OPERATION);

		}
		returnStringBuffer.append(Constants.QUOTE + "Total Entries Processed"
				+ Constants.QUOTE + Constants.COMMA + entriesProcessed);
		returnStringBuffer.append(Constants.END_OF_LINE);

		returnStringBuffer.append(Constants.QUOTE + "Persons Failed"
				+ Constants.QUOTE + Constants.COMMA + personsFailed);
		returnStringBuffer.append(Constants.END_OF_LINE);

		returnStringBuffer.append(Constants.QUOTE + "Added Person"
				+ Constants.QUOTE + Constants.COMMA + personsAdded);
		returnStringBuffer.append(Constants.END_OF_LINE);

		returnStringBuffer.append(Constants.QUOTE + "Modified Person"
				+ Constants.QUOTE + Constants.COMMA + personsModified);
		returnStringBuffer.append(Constants.END_OF_LINE);

		//			 Create Table for Newly Added Persons
		if (personsAdded > 0) {

			if (isWorkflow) {

				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_ENTRIES_FOR_PERSONS_WITH_WORKFLOW);
				pstatement.setString(1, reconId);
				pstatement.setString(2, Constants.PENDING_ADD_PERSON_OPERATION);
				pstatement.setString(3,
						Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_ADD);
			} else {

				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW);
				pstatement.setString(1, reconId);
				pstatement.setString(2, Constants.PERSONS_ADDED_OPERATION);
			}
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE + "Persons Added Table"
					+ Constants.QUOTE);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE + "No Of Persons"
					+ Constants.QUOTE + Constants.COMMA + personsAdded
					+ Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE + "Persons"
					+ Constants.QUOTE);
			returnStringBuffer.append(Constants.END_OF_LINE);
			try {

				rs = pstatement.executeQuery();
				while (rs.next()) {
					returnStringBuffer.append(" " + Constants.COMMA
							+ Constants.QUOTE
							+ processDoubleQuotes(rs.getString(1))
							+ Constants.QUOTE);

					returnStringBuffer.append(Constants.END_OF_LINE);

				}
				returnStringBuffer.append(Constants.END_OF_LINE);
				returnStringBuffer.append(Constants.END_OF_LINE);
			} catch (Exception e) {
				System.out
						.println("Exception while Processing entries for Persons Added table ");
				e.printStackTrace();
			} finally {
				safeClose(rs);
				safeClose(pstatement);
			}
		}

		//	 Create Table for Newly Modified Persons

		if (personsModified > 0) {

			if (isWorkflow) {

				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_ENTRIES_FOR_PERSONS_WITH_WORKFLOW);
				pstatement.setString(1, reconId);
				pstatement.setString(2,
						Constants.PENDING_MODIFY_PERSON_OPERATION);
				pstatement.setString(3,
						Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_MODIFY);
			} else {

				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW);
				pstatement.setString(1, reconId);
				pstatement.setString(2, Constants.PERSONS_MODIFIED_OPERATION);
			}
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE
					+ "Persons Modified Table" + Constants.QUOTE);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE + "No Of Persons"
					+ Constants.QUOTE + Constants.COMMA + personsModified
					+ Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE + "Persons"
					+ Constants.QUOTE);
			try {
				rs = pstatement.executeQuery();
				while (rs.next()) {
					returnStringBuffer.append(" " + Constants.COMMA
							+ Constants.QUOTE
							+ processDoubleQuotes(rs.getString(1))
							+ Constants.QUOTE);
				}
				returnStringBuffer.append(Constants.END_OF_LINE);
				returnStringBuffer.append(Constants.END_OF_LINE);
				safeClose(rs);
				safeClose(pstatement);
			} catch (Exception e) {
				System.out
						.println("Exception while Processing entries for Persons Modified Table ");
				e.printStackTrace();
			} finally {
				safeClose(rs);
				safeClose(pstatement);
			}
		}

		//			Create Table for Persons failed additions/nodifications
		if (personsFailed > 0) {

			if (isWorkflow) {
				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITH_WORKFLOW
								+ Constants.UNION
								+ Constants.QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITH_WORKFLOW_2);
				pstatement.setString(1, reconId);
				pstatement.setString(2, Constants.FAILED_ADD_PERSON_OPERATION);
				pstatement.setString(3,
						Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_ADD);
				pstatement.setString(4,
						Constants.FAILED_MODIFY_PERSON_OPERATION);
				pstatement.setString(5,
						Constants.RECON_WORKFLOW_DEFINITION_ID_PERSON_MODIFY);
				pstatement.setString(6, reconId);

			} else {
				pstatement = con
						.prepareStatement(Constants.QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW);
				pstatement.setString(1, reconId);
				pstatement.setString(2, Constants.PERSONS_MODIFIED_OPERATION);
			}

			rs=pstatement.executeQuery();
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE + "Persons Failed Table"
					+ Constants.QUOTE);
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.QUOTE + "Persons"
					+ Constants.QUOTE + Constants.COMMA + Constants.QUOTE
					+ "Reason" + Constants.QUOTE + Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.END_OF_LINE);

			try {
				boolean tempUseWorkflow = isWorkflow;

				while (true) {
					while (rs.next()) {

						returnStringBuffer.append(" " + Constants.COMMA
								+ Constants.QUOTE
								+ processDoubleQuotes(rs.getString(1))
								+ Constants.QUOTE);
					}

					// Add Person who failed with FAP or FMP although
					// they were to be processed by workflow

					if (addFailedPerson && isWorkflow) {
						pstatement = con
								.prepareStatement(Constants.QUERY_FOR_FAILED_ENTRIES_FOR_PERSONS_WITHOUT_WORKFLOW);
						pstatement.setString(1, reconId);
						pstatement.setString(2,
								Constants.PERSONS_MODIFIED_OPERATION);
						rs = pstatement.executeQuery();
						addFailedPerson = false;
						tempUseWorkflow = false;
					} else
						break;

				}

				returnStringBuffer.append(Constants.END_OF_LINE);
				returnStringBuffer.append(Constants.END_OF_LINE);
			}

			catch (Exception e) {
				System.out
						.println("Exception while processing entries for Persons Failed table");
				e.printStackTrace();
			} finally {
				safeClose(rs);
				safeClose(pstatement);
			}
		}

		// TODO Auto-generated method stub
		return returnStringBuffer;

	}

	/*
	 * (non-Java-doc)
	 *
	 * @see javax.servlet.http.HttpServlet#doPost(HttpServletRequest request,
	 *      HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		doGet(request, response);

	}

	// function to add data specific to Account Recons
	public StringBuffer appendAccountReconciliationSummarydata(String reconId) {
		int entriesProcessed = 0;
		int orphanAccounts = 0;
		int ownedAccounts = 0;
		int policyViolations = 0;
		int newLocalAccounts = 0;
		int removedLocalAccounts = 0;
		int dpAccounts = 0;
		int modifiedAccounts = 0;
		int suspendedAccounts = 0;
		StringBuffer returnStringBuffer = new StringBuffer();
		pstatement=null;

		try {

			pstatement = con
					.prepareStatement(Constants.QUERY_FOR_RECON_SUMMARY_OF_ACCOUNT);
			pstatement.setString(1, reconId);
			rs = pstatement.executeQuery();
			while (rs.next()) {
				entriesProcessed = rs.getInt(1);
				ownedAccounts = rs.getInt(2);
				policyViolations = rs.getInt(3);
				newLocalAccounts = rs.getInt(4);

				returnStringBuffer.append(Constants.QUOTE
						+ "Total Entries Processed" + Constants.QUOTE
						+ Constants.COMMA + entriesProcessed);
				returnStringBuffer.append(Constants.END_OF_LINE);

				returnStringBuffer.append(Constants.QUOTE
						+ "Total Owned Accounts" + Constants.QUOTE
						+ Constants.COMMA + ownedAccounts);
				returnStringBuffer.append(Constants.END_OF_LINE);

				returnStringBuffer.append(Constants.QUOTE + "Policy Violations"
						+ Constants.QUOTE + Constants.COMMA + policyViolations);
				returnStringBuffer.append(Constants.END_OF_LINE);

				returnStringBuffer.append(Constants.QUOTE
						+ "New Local Accounts" + Constants.QUOTE
						+ Constants.COMMA + newLocalAccounts);
				returnStringBuffer.append(Constants.END_OF_LINE);

			}

			orphanAccounts = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.ORPHAN_ACCOUNTS_OPERATION);

			modifiedAccounts = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.MODIFIED_ACCOUNTS_OPERATION);

			removedLocalAccounts = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.REMOVED_LOCAL_ACCOUNTS_OPERATION);

			dpAccounts = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.DEPROVISIONED_ACCOUNT_OPERATION);

			suspendedAccounts = getCountOfEntriesFromReconInfoTable(reconId,
					Constants.SUSPENDED_ACCOUNT_OPERATION);

			returnStringBuffer.append(Constants.QUOTE + "Orphan Accounts"
					+ Constants.QUOTE + Constants.COMMA + orphanAccounts);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE + "Modified Accounts"
					+ Constants.QUOTE + Constants.COMMA + modifiedAccounts);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE
					+ "Removed Local Accounts" + Constants.QUOTE
					+ Constants.COMMA + removedLocalAccounts);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE
					+ "Deprovisioned Accounts" + Constants.QUOTE
					+ Constants.COMMA + dpAccounts);
			returnStringBuffer.append(Constants.END_OF_LINE);

			returnStringBuffer.append(Constants.QUOTE + "Suspended Accounts"
					+ Constants.QUOTE + Constants.COMMA + suspendedAccounts);
			returnStringBuffer.append(Constants.END_OF_LINE);
			returnStringBuffer.append(Constants.END_OF_LINE);

		}

		catch (Exception e) {
			System.out
					.println("Exception while Processing Summary data for Account Reconciliation ");
			e.printStackTrace();
		}
		finally{
			safeClose(rs);
			safeClose(pstatement);
		}
		return returnStringBuffer;
	}

	private int getCountOfEntriesFromReconInfoTable(String reconId,
			String operation) throws SQLException {
		int numEntries = 0;

		String sql = Constants.QUERY_FOR_COUNT_OF_ENTRIES_FROM_RECON_INFO;
		pstatement = con.prepareStatement(sql);
		pstatement.setString(1, reconId);
		pstatement.setString(2, operation);
		ResultSet rs = pstatement.executeQuery();
		try {
			if (rs.next()) {
				numEntries = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out
					.println("Exception while Getting the Count of Entries from the table");
			e.printStackTrace();
		} finally {
			safeClose(rs);
			safeClose(pstatement);
		}
		return numEntries;
	}

	private ResultSet getEntriesFromReconInfoTable(String reconID,
			String operation) throws SQLException {
		pstatement = con
				.prepareStatement(Constants.QUERY_FOR_ENTRIES_FROM_RECON_INFO);
		pstatement.setString(1, reconID);
		pstatement.setString(2, operation);
		return rs = pstatement.executeQuery();
	}

	//The ResultSet will have only a single column
	private String addTableToReport(ResultSet rs, String title)
			throws SQLException {
		StringBuffer sb = new StringBuffer();
		//Add title to sb
		sb.append(title);
		sb.append(Constants.END_OF_LINE);
		//Iteratore over result set and add accounts to sb
		if (rs != null) {
			while (rs.next()) {
				sb.append(" " + Constants.COMMA + Constants.QUOTE
						+ processDoubleQuotes(rs.getString(1))
						+ Constants.QUOTE);
				sb.append(Constants.END_OF_LINE);
			}
		}
		sb.append(Constants.END_OF_LINE);
		sb.append(Constants.END_OF_LINE);
		safeClose(rs);
		return sb.toString();
	}

	/*
	 * Safely close a statement.
	 *
	 * This method is safe to call with null.
	 * If an Exception is caught, it will be traced (and consumed).
	 *
	 * @param stmt JDBC statement we are closing.
	 */
	private void safeClose(Statement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
				stmt = null;
			} catch (Exception e) {
				System.out.println("Exception while closing the Statement ");
				e.printStackTrace();
			}
		}
	}

	private void safeClose(Connection con) {
		if (con != null) {
			try {
				con.close();
				con = null;
			} catch (Exception e) {
				System.out.println("Exception while closing the connection ");
				e.printStackTrace();
			}
		}
	}

	/*
	 * Safely close a statement.
	 *
	 * This method is safe to call with null.
	 * If an Exception is caught, it will be traced (and consumed).
	 *
	 * @param stmt JDBC statement we are closing.
	 */
	private void safeClose(PreparedStatement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
				stmt = null;
			} catch (Exception e) {
				System.out
						.println("Exception while closing the PreparedStatement ");
				e.printStackTrace();
			}
		}
	}

	/*
	 * Safely close a result set.
	 *
	 * This method is safe to call with null.
	 * If an Exception is caught, it will be traced (and consumed).
	 *
	 * @param result JDBC result set  we are closing.
	 */
	private void safeClose(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
				rs = null;
			} catch (Exception e) {
				System.out.println("Exception while closing the Resultset ");
				e.printStackTrace();
			}
		}
	}

	//function to handle the Strings(like Account -id) containing , or " in it
	public String processDoubleQuotes(String value) {
		if (value == null)
			return "";
		//		String replacedString=value.replaceAll("\"", "\"\"");
		//		return(Constants.QUOTE+replacedString+Constants.QUOTE);

		return value.replaceAll("\"", "\"\"");
	}

	//function to check for use of Workflow during Reconciliation
	public boolean checkforworkflow(String reconId) {
		pstatement = null;
		int numEntries = 0;
		try {
			pstatement = con
					.prepareStatement(Constants.QUERY_FOR_CHECK_WORKFLOW);
			pstatement.setString(1, reconId);
			rs = pstatement.executeQuery();
			if (rs.next()) {
				numEntries = rs.getInt(1);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception while Checking for Workflow ");
			e.printStackTrace();
		}finally{
			safeClose(rs);
			safeClose(pstatement);
		}

		if (numEntries > 0)
			return (true);
		else
			return (false);

	}

}
