/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2009 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/

package com.ibm.itim.hookedreport;

/**
 * This class contains all the constants that are required to establish the Database connection while generating Reconciliation Hooked Report
 */

public class DBConnectionConstants {

	/*
	 * JDBC Driver URL
	 * E.g. public static final String DATABASE_URL = "jdbc:db2://localhost:50000/db1";
	 */
	public static final String DATABASE_URL = "";

	/*
	 * ITIM Database User
	 * E.g. public static final String USERNAME = "enrole";
	 */
	public static final String USERNAME = "";

	/*
	 * ITIM Database Password for specified user
	 * The password should be clear-text
	 * E.g. public static final String PASSWORD = "kk39kcD";
	 */
	public static final String PASSWORD = "";

	/*
	 * JDBC Driver Name
	 * E.g.	public static final String DATABASE_DRIVER = "com.ibm.db2.jcc.DB2Driver";
	 */
	public static final String DATABASE_DRIVER = "";

	/*
	 * ITIM Database Owner
	 * E.g. public static final String DATABASE_OWNER = "enrole";
	 */
	public static final String DATABASE_OWNER = "";

}
