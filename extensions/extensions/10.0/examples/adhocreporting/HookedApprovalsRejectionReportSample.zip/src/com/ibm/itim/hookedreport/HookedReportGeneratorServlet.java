/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2009 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/

package com.ibm.itim.hookedreport;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * This servlet will be invoked from the HookedReport.jsp.
 * @author
 *
 */

public class HookedReportGeneratorServlet extends HttpServlet {
    /**
     *
     */
    private static final long serialVersionUID = 18596631L;
    private static final String REPORT_FORMAT     = "ReportFormat";
    private static final String REPORT_TYPE = "ReportType";
    private static final String CSV_FORMAT = "csv";

    public void service(HttpServletRequest req, HttpServletResponse res) {

        HttpSession thisSession = req.getSession( false );
        String reportXML = null;
        String reportHeader = null;
        if ( thisSession != null ){

            String format = req.getParameter(REPORT_FORMAT);
            String reportType = req.getParameter(REPORT_TYPE);

            if(format == null || format.trim().equals("")) {
                format = "csv";
            }
            if(reportType == null || reportType.trim().equals("")) {
                reportType = "All";
            }
            if(!format.equals(CSV_FORMAT)){
                writeToStream(res, "Unsupported report format" );
                return;
            } else {
                reportHeader = HookedReport.getCSVreportHeader(req, reportType);
                reportXML = HookedReport.generateCSVReport(req, reportType);
                if (reportXML.indexOf("SQL ERROR") != -1 || reportXML.indexOf("ClassNotFoundException") != -1) {
                    reportXML = " An error occured while generting the report. Please check system Err log file";
                    writeToStream(res, reportXML );
                } else {
                    res.setHeader("Content-type", "text/plain" );
                    res.setHeader("Content-Disposition", "attachment; filename=Report.csv" );
                    writeToStream(res,reportHeader + reportXML );
                }
            }

        }else {
            try {
                ServletContext sc = getServletConfig().getServletContext();
                RequestDispatcher dispatcher = sc.getRequestDispatcher( "/popUpSessionTimedOut.jsp" );
                dispatcher.forward( req, res );
            } catch(Exception e) {
                System.out.println(" An exception occured : service(),"+ e.getMessage());
            }
        }
    }



    /**
     * Write batch to ouput stream
     */
    private void writeToStream(HttpServletResponse res, String str) {
         try {
             res.getOutputStream().write(str.getBytes("UTF-8"));
            } catch (Exception e) {
                System.out.println("CSV Report write stream exception: "
                        + e.getMessage());
            }
    }
}
