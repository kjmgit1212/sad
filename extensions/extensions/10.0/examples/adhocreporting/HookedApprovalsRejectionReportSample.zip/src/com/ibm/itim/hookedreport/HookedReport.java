/********************************************************************
*  Licensed Materials - Property of IBM
*  
*  (c) Copyright IBM Corp.  2009 All Rights Reserved
*  
*  US Government Users Restricted Rights - Use, duplication or
*  disclosure restricted by GSA ADP Schedule Contract with
*  IBM Corp.
********************************************************************/

package com.ibm.itim.hookedreport;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.SimpleTimeZone;
import java.util.TimeZone;


import javax.servlet.http.HttpServletRequest;

/**
 * Hooked Report class:
 * 1. Parses the user input values from the HttpServletRequest
 * 2. Creates CSV report header
 * 3. Creates DataBase connection
 * 4. Fetches the database depening upon the query
 * 5. Iterates resultset and form a string containing the report data to be
 *     displayed on a CSV file
 *
 */

public class HookedReport {

    private static final String reportCriteria = "Report Criteria";
    private static final String datePrinted = "Date Printed";
    private static final String timePrinted = "Time Printed";
    private static final String approver = "Approver";
    private static final String timeOfAction = "Time of Action (Approve/Reject)";
    private static final String serviceType = "Service Type";
    private static final String serviceName = "Service Name";
    private static final String userID = "User ID";
    private static final String status = "Status";
    private static final String approvalActivityName = "Approval Activity Name";
    private static final String Requester = "Requester";
    private static final String Requestee = "Requestee";
    private static final String END_OF_LINE = "\n";
    private static final String QUOTE = "\"";
    private static final String COMMA = ",";
    private static final String ALL = "All";
    private static final String PERSON = "Person";
    private static final String ACCOUNT = "Account";


    private static String [] accountReportFields = new String [] {approver,
        timeOfAction, serviceType, serviceName, userID, status, approvalActivityName};

    private static String [] personReportFields = new String [] {approver,
        timeOfAction, status, approvalActivityName, Requestee, Requester};

    private static String [] allReportFields = new String [] {approver,
        timeOfAction, serviceType, serviceName, userID, status, approvalActivityName, Requestee};


    private static String sqlForPerson = "SELECT PROCESSLOG.REQUESTOR, " +
            "ACTIVITY.COMPLETED, ACTIVITY.RESULT_SUMMARY, ACTIVITY.NAME, " +
            "PROCESS.REQUESTEE_NAME, PROCESS.REQUESTER_NAME "+
            "FROM PROCESS, PROCESSLOG, ACTIVITY " +
            "WHERE PROCESSLOG.PROCESS_ID = PROCESS.ID AND " +
            "PROCESSLOG.ACTIVITY_ID = ACTIVITY.ID AND ACTIVITY.PROCESS_ID = PROCESS.ID " +
            "AND ACTIVITY.SUBTYPE = 'AP' AND PROCESS.SUBJECT_SERVICE IS NULL AND " +
            "PROCESSLOG.EVENTTYPE = 'CM' AND PROCESSLOG.REQUESTOR LIKE ? AND " +
            "ACTIVITY.COMPLETED > ? AND  ACTIVITY.COMPLETED < ? AND " +
            "ACTIVITY.RESULT_SUMMARY LIKE ? AND ACTIVITY.NAME LIKE ?";


    private static String sqlForAccount = "SELECT PROCESSLOG.REQUESTOR, " +
            "ACTIVITY.COMPLETED, SERVICE.SERVICETYPE, SERVICE.ERSERVICENAME, " +
            "PROCESS.SUBJECT, ACTIVITY.RESULT_SUMMARY, ACTIVITY.NAME, " +
            "PROCESS.REQUESTEE_NAME FROM SERVICE, PROCESS, PROCESSLOG, ACTIVITY, SERVICE_ACCOUNT_MAPPING " +
            "WHERE PROCESSLOG.PROCESS_ID = PROCESS.ID AND PROCESSLOG.ACTIVITY_ID = ACTIVITY.ID " +
            "AND PROCESSLOG.EVENTTYPE = 'CM' AND ACTIVITY.SUBTYPE = 'AP' "+
            "AND SERVICE.ERSERVICENAME = PROCESS.SUBJECT_SERVICE "+
            "AND ACTIVITY.PROCESS_ID = PROCESS.ID " +
            "AND PROCESS.SUBJECT_PROFILE = SERVICE_ACCOUNT_MAPPING.ACCOUNTPROFILE "+
            "AND SERVICE_ACCOUNT_MAPPING.SERVICEPROFILE = SERVICE.SERVICETYPE "+
            "AND PROCESSLOG.REQUESTOR LIKE ? " +
            "AND ACTIVITY.COMPLETED > ? AND ACTIVITY.COMPLETED < ? " +
            "AND Service.servicetype LIKE ? AND Service.erservicename LIKE ? " +
            "AND PROCESS.SUBJECT LIKE ? AND ACTIVITY.RESULT_SUMMARY LIKE ? AND " +
            "ACTIVITY.NAME LIKE ? ";







    /**
     * Creates a report header containing Time, date and report columns.
     * @param req
     * @param reportType
     * @return String represenation of report header
     */
    public static String getCSVreportHeader(HttpServletRequest req, String reportType) {


        String  clientDate = getClientDate();
        Date date = new Date();
        StringBuffer reportHeader = new StringBuffer(10);

        reportHeader.append(QUOTE + reportCriteria + QUOTE);
        reportHeader.append (END_OF_LINE);
        reportHeader.append(QUOTE + datePrinted + QUOTE);
        reportHeader.append(COMMA);
        reportHeader.append(QUOTE + clientDate + QUOTE);
        reportHeader.append (END_OF_LINE);

        reportHeader.append(QUOTE + timePrinted + QUOTE);
        reportHeader.append(COMMA);
        reportHeader.append(QUOTE + date.getHours()+":" + date.getMinutes() +":"+ date.getSeconds() + QUOTE);
        reportHeader.append (END_OF_LINE);

        reportHeader.append(QUOTE + approver + QUOTE);
        reportHeader.append(COMMA);
        reportHeader.append(QUOTE + timeOfAction + QUOTE);
        reportHeader.append(COMMA);
        if(!reportType.equals(PERSON)) {
            reportHeader.append(QUOTE + serviceType + QUOTE);
            reportHeader.append(COMMA);
            reportHeader.append(QUOTE + serviceName + QUOTE);
            reportHeader.append(COMMA);
            reportHeader.append(QUOTE + userID + QUOTE);
            reportHeader.append(COMMA);
        }
        reportHeader.append(QUOTE + status + QUOTE);
        reportHeader.append(COMMA);
        reportHeader.append(QUOTE + approvalActivityName + QUOTE);
        reportHeader.append(COMMA);
        if(reportType.equals(PERSON)) {
            reportHeader.append(QUOTE + Requestee + QUOTE);
            reportHeader.append(COMMA);
            reportHeader.append(QUOTE + Requester + QUOTE);
            reportHeader.append(COMMA);
        }
        if(reportType.equals(ALL)) {
              reportHeader.append(QUOTE + Requestee + QUOTE);
              reportHeader.append(COMMA);
        }
        reportHeader.append (END_OF_LINE);


        return reportHeader.toString();
    }


    /**
     * Returns the string represenation of report data
     * @param req
     * @param reportType
     * @return
     */
    public static String generateCSVReport(HttpServletRequest req,  String reportType) {
        Connection con = null;
        String reportXML = "";
        ArrayList inputParam;
        try {
            con = getDBConnection(req);

            if(reportType.equalsIgnoreCase(ALL)) {
                inputParam = getInputParameters(req, ACCOUNT);
                reportXML = getReportXML(con,inputParam, ACCOUNT , reportType);

                inputParam = getInputParameters(req, PERSON);
                reportXML  = reportXML + getReportXML(con,inputParam, PERSON, reportType);
            }
            if(reportType.equalsIgnoreCase(PERSON)) {
                inputParam = getInputParameters(req, PERSON);
                reportXML = getReportXML(con,inputParam, PERSON, reportType);
            }
            if(reportType.equalsIgnoreCase(ACCOUNT)) {
                inputParam = getInputParameters(req, ACCOUNT);
                reportXML = getReportXML(con,inputParam, ACCOUNT , reportType);
            }
            return reportXML;
        } catch (SQLException e) {
            e.printStackTrace();
             return "SQL ERROR";
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            return "ClassNotFoundException";
        }

    }

    /**
     * Retruns the current date with form  "MM-dd-yy"
     * @return strDate
     */
    private static String getClientDate() {
        java.util.Date date = new Date();
        String formatPattern = "MM-dd-yy";
        SimpleDateFormat aFormat = new SimpleDateFormat(formatPattern);
        String strDate = aFormat.format(date);
        return strDate;
    }


    /**
     * Creates and returns a database connection to the ITIM database
     * @param req
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException
     */
    private static Connection getDBConnection(HttpServletRequest req) throws SQLException, ClassNotFoundException{

        String jdbcDriver = req.getParameter("jdbcdriver");
        String jdbcURL = req.getParameter("jdbcurl");
        String dbuser = req.getParameter("dbuser");
        String dbpassword = req.getParameter("dbpassword");

        Connection connection = null;
        try {
            Class.forName(jdbcDriver);
        } catch (ClassNotFoundException e) {
            System.out.println(" DataBase driver class not found in the classpath");
            throw e;
        }
        connection = DriverManager.getConnection(jdbcURL, dbuser,dbpassword);
        return connection;

    }


    /**
     * Parses the HttpServletRequest and creates an ArrayList of inputParameter
     * @param req
     * @param reportType
     * @return inputParam
     */
    private static ArrayList getInputParameters(HttpServletRequest req, String reportType) {
        ArrayList inputParam = new ArrayList();
        String approver = req.getParameter("approver");
        String serviceType = req.getParameter("serviceType");
        String startDate = getDate(req, "UserInput1");
        String endDate = getDate(req, "UserInput2");
        String serviceName = req.getParameter("serviceName");
        String userID = req.getParameter("userID");
        String status = req.getParameter("status");
        String approvalActivityName = req.getParameter("approvalActivityName");

        if(approver == null || approver.trim().equals("*")) {
            approver = "%";
        }
        if(startDate == null || startDate.trim().equals("*")) {
            startDate = "%";
        }
        if(serviceType == null || serviceType.trim().equals("*")) {
            serviceType = "%";
        }
        if(serviceName == null || serviceName.trim().equals("*")) {
            serviceName = "%";
        }
        if(endDate == null || endDate.trim().equals("*")) {
            endDate = "%";
        }
        if(userID == null || userID.trim().equals("*")) {
            userID = "%";
        }
        if(status == null || status.trim().equals("All")) {
            status = "%";
        } else if(status.trim().equals("Approved")) {
            status = "AA";
        } else if(status.trim().equals("Rejected")) {
            status = "AR";
        }
        if(approvalActivityName == null || approvalActivityName.trim().equals("*")) {
            approvalActivityName = "%";
        }

        inputParam.add(approver);
        inputParam.add(startDate);
        inputParam.add(endDate);
        if(reportType.equals(ACCOUNT)) {
            inputParam.add(serviceType);
            inputParam.add(serviceName);
            inputParam.add(userID);
        }
        inputParam.add(status);
        inputParam.add(approvalActivityName);

        return inputParam;
    }

    /**
     * From the userinput date value, gets the Date in the form of "yyyy-MM-dd HH:mm:ss:SSS zzz"
     * @param req
     * @param userInput
     * @return date String
     */
    private static String getDate(HttpServletRequest req, String userInput) {
        String dayStr = req.getParameter(userInput + ".date.day");
        int day = Integer.parseInt(dayStr);
        int month = Integer.parseInt(req
                .getParameter(userInput + ".date.month"));
        int year = Integer.parseInt(req.getParameter(userInput + ".date.year"));
        String timeStr = req.getParameter(userInput + ".date.time");

        int hour = Integer.parseInt(timeStr.substring(0, timeStr.indexOf(":")));
        int minute = Integer.parseInt(timeStr.substring(
                timeStr.indexOf(":") + 1, timeStr.length()));

        Locale userLocale = req.getLocale();
        SimpleTimeZone tz = new SimpleTimeZone(0, "");

        Calendar cal = Calendar.getInstance(tz, userLocale);
        cal.set(year, month - 1, day, hour, minute);
        java.util.Date clDate = cal.getTime();

        SimpleDateFormat aFormat = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss:SSS zzz");
        TimeZone timezone = TimeZone.getTimeZone("GMT");
        aFormat.setTimeZone(timezone);
        return aFormat.format(clDate);

    }

    /**
     * Iterates through the result set and appends the data to a string.
     * @param con
     * @param inputParam
     * @param type
     * @param reportType
     * @return returnXML.toString();
     * @throws SQLException
     */
    private static String getReportXML(Connection con, ArrayList inputParam, String type, String reportType) throws SQLException{
        PreparedStatement stmt = null;
        ResultSet rs = null;
        StringBuffer returnXML = new StringBuffer();
        int statusCol = 0;

        if(type.equals(PERSON)) {
            stmt = con.prepareStatement(sqlForPerson);
            statusCol = 3;

        } else if(type.equals(ACCOUNT)) {
            statusCol = 6;
             stmt = con.prepareStatement(sqlForAccount);
        }

        for(int i = 0; i<inputParam.size(); i++) {
            stmt.setString(i+1, (String)inputParam.get(i));
        }
        rs = stmt.executeQuery ();

        int colLimit = 0;
        if(type.equals(ACCOUNT)) {
            if(reportType.equals(ALL)) {
                colLimit = allReportFields.length;
            } else {
                colLimit = accountReportFields.length;
            }

        } else if(type.equals(PERSON)  ) {
            if(reportType.equals(ALL)) {
                colLimit = personReportFields.length -1 ;
            } else {
                colLimit = personReportFields.length;
            }
        }
        while(rs.next()){
            String value = null;
            int i = 0;
            int colIndex = 0;
            while (i < colLimit) {
                value = rs.getString(i+1);
                if( value == null){
                    value = "";
                }
                if (colIndex > 0) {
                    returnXML.append (COMMA);
                }
                i++;
                if (statusCol == i) {
                    if(value.equals("AR")) {
                        value = "Rejected";
                    } else if(value.equals("AA")) {
                        value = "Approved";
                    }
                }
                returnXML.append (QUOTE + (value) + QUOTE);
                if(!type.equals(reportType) && type.equals(PERSON)) {
                    if(i == 2) {
                        returnXML.append (COMMA);
                        returnXML.append (COMMA);
                        returnXML.append (COMMA);
                    }
                }
                colIndex++;
            }
            returnXML.append (END_OF_LINE);
        }
        return returnXML.toString();
    }
}
