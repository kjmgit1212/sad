
The "Approvals and Rejections" report is designed to display approval activities associated with account
related requests only. If the customer requirement is to display both account as well as person related 
Approval/Rejection activities, then the customer can use HookedReport facility available in the ITIM Report 
Component. Please see the HookedApprovalsRejectionReportSample.zip for creating HookedReport. 
In addition to the instruction, we have provided an example HookedReport to display "Approvals and Rejections" requests of both Person and Account related activities. You can refer to this example to create more customized Hooked Report.


Steps to create a Hooked report.

1. Develop a servlet or a JSP page to take the User Input from User as Report criterion.

2. If a servlet is developed, then place the servlet mapping entries in the web.xml file of enRole application
   present in 
   <WAS_HOME>\profiles\<profile-name>\config\cells\<node-name>\applications\ITIM.ear\deployments\ITIM\itim_console.war\WEB-INF
   and
   <WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear\itim_console.war\WEB-INF directory.

3. Write java code in the servlet itself or in any new java file to query the database depending upon the user input

4. Also write code to display the results to the user in the form of CSV or PDF form.

5. Add the report entry into the report.xml present under <ITIM-HOME>\data 

6. If custom java or servlet is developed, then put the class files (or archived jar files) in the class path
   One can edit the MANIFEST file present under <WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear\itim_console.war\META-INF\    directory by adding the name of the custom jar file to place the custom jar file in the Application Server classpath.

7. Restart the Application Server.

8. The report name "Hooked Report" mentioned in the report.xml file above will appear in the Run Report Tab of Report 
   component of ITIM GUI under section "Custom Reports".

9. Run the report as any other ITIM report.

Please note****: ITIM Administrator can define ACI on the Hooked Report. However, other ACI enforcement in the ITIM will 
not be applicable for the data displayed on the Hooked Report. Therefore please be cautious when defining ACI to run 
the Hooked Report to the non-admin users as the user can see any data that will be displayed on the Hooked Report.


To work with the example Hooked Report:

1. Copy the HookedReport.jsp into <WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear\itim_console.war\report(Create new folder report)
2. Edit the HookedReport.jsp and replace the values of the variables (jdbcdriver, jdbcurl, dbuser and dbpassword) with
   correct values
3. Copy the HookedReport.jar into <WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear
4. Add the entry, HookedReport.jar into  <WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear\itim_console.war\META-INF\MANIFEST.INF file
5. Place the servlet url mapping in the web.xml present under folder
<WAS_HOME>\profiles\<profile-name>\config\cells\<node-name>\applications\ITIM.ear\deployments\ITIM\itim_console.war\WEB-INF
and 
<WAS_HOME>\profiles\<profile-name>\installedApps\<node-name>\ITIM.ear\itim_console.war\WEB-INF

	<servlet>
		<servlet-name>HookedReportGeneratorServlet</servlet-name>
		<description>HookedReportGeneratorServlet</description>
		<servlet-class>com.ibm.itim.hookedreport.HookedReportGeneratorServlet</servlet-class>
	</servlet>
	<servlet-mapping >
		<servlet-name>HookedReportGeneratorServlet</servlet-name>
		<url-pattern>HookedReport_Generator_Servlet</url-pattern>
	</servlet-mapping>

6. Edit the report.xml present under <ITIM-HOME>\data and add entry the following entry:

	<report name="Hooked Report" action="popup">
		<url>./HookedReport.jsp</url>
	</report>

7. Re-start the Application Server and go to Report->Run Report. Make sure that "Hooked Report" is present under 
   "Custom Report" section.


Note: For Cluster setup, repeat steps 1 to 6 mentioned above for each node in the cluster, then restart the cluster.